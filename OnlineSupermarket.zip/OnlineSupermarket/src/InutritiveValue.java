public interface InutritiveValue {
    public double proteinRatio();
    public double fatRatio();
    
}
